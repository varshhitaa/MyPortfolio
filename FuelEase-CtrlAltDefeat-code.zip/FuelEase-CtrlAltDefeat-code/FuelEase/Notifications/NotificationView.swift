//
//  NotificationView.swift
//  FuelEase
//
//  Created by Varshita Yarabadi on 11/17/23.
//

import SwiftUI
import WebKit

// Struct to decode the YouTube API response
struct YouTubeSearchResponse: Codable {
    struct Item: Codable {
        struct ID: Codable {
            let videoId: String
        }
        struct Snippet: Codable {
            let title: String
            let description: String
        }
        let id: ID
        let snippet: Snippet
    }
    let items: [Item]
}

// WebView to display the YouTube video
struct WebView: UIViewRepresentable {
    let videoID: String

    func makeUIView(context: Context) -> WKWebView {
        let webView = WKWebView()
        webView.scrollView.isScrollEnabled = false
        return webView
    }

    func updateUIView(_ uiView: WKWebView, context: Context) {
        guard let url = URL(string: "https://www.youtube.com/embed/\(videoID)") else { return }
        uiView.load(URLRequest(url: url))
    }
}

struct NotificationView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @State private var searchText = ""
    @State private var videoID = ""
    @State private var videoTitle = ""
    @State private var videoDescription = ""
    @State private var showWebView = false

    let backgroundColor = Color("BackgroundColor")
    let textColor = Color("TextColor")
    var body: some View {
        ZStack {
            backgroundColor.ignoresSafeArea()
            ScrollView {
                VStack {
                    Text("Notifications")
                        .font(.custom("AbhayaLibre-ExtraBold", size: 55))
                        .foregroundColor(textColor)
                        .padding(.top, -10)
                    // AccordionView
                    AccordionView(title: "Tips for new users", items: [
                        "Onboarding Tips: New to FuelEase? See Maps view to explore nearby gas stations and navigate yourself.",
                        "FAQs and Help Center: Need help? Check out our Help Center to submit any questions or concerns.",
                        "App Rating and Feedback: Enjoying FuelEase? Rate us on the Rate us tabs in our app and share your feedback. Your input helps us improve!"
                    ])
                    .padding(.vertical, 10)
                    VStack {
                        Text("Search a video on driving lessons")
                            .font(.custom("AbhayaLibre-ExtraBold", size: 26))
                            .foregroundColor(textColor)
                            .padding(.vertical, 10)
                        TextField("Search YouTube", text: $searchText)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .padding()
                            .font(.custom("AbhayaLibre-ExtraBold", size: 20))
                            .foregroundColor(textColor)
                        
                        Button("Search") {
                            searchYouTube()
                        }
                        .padding()
                        .foregroundColor(.white)
                        .background(textColor)
                        .font(.custom("AbhayaLibre-ExtraBold", size: 20))
                        .cornerRadius(20)
                        if showWebView {
                            WebView(videoID: videoID)
                                .frame(height: 170)
                            Text(videoTitle)
                                .background(Color.color)
                                .font(.custom("AbhayaLibre-ExtraBold", size: 20))
                                .cornerRadius(1)
                            Text(videoDescription)
                                .background(Color.color)
                                .font(.custom("AbhayaLibre-ExtraBold", size: 20))
                                .cornerRadius(1)
                        }
                    }
                }
            }
            .navigationBarBackButtonHidden(true)
            .onAppear {
                UITabBar.appearance().isHidden = true
            }
            .onDisappear {
                UITabBar.appearance().isHidden = false
            }
        }
    }
    // This function needs to be within the scope of NotificationView to access its @State properties
        func searchYouTube() {
            guard let url = URL(string: "https://www.googleapis.com/youtube/v3/search") else { return }

            let parameters: [String: String] = [
                "key": "AIzaSyBtDLwKoVF_qln1aikD8Ec-s61zyngkuV4",
                "q": searchText,
                "part": "snippet",
                "maxResults": "1",
                "type": "video",
                "videoEmbeddable": "true"
            ]

            let session = URLSession.shared
            var urlComponents = URLComponents(url: url, resolvingAgainstBaseURL: true)
            urlComponents?.queryItems = parameters.map { URLQueryItem(name: $0.key, value: $0.value) }

            guard let finalURL = urlComponents?.url else { return }

            session.dataTask(with: finalURL) { data, response, error in
                if let data = data, let response = try? JSONDecoder().decode(YouTubeSearchResponse.self, from: data) {
                    DispatchQueue.main.async {
                        if let item = response.items.first {
                            self.videoID = item.id.videoId
                            self.videoTitle = item.snippet.title
                            self.videoDescription = item.snippet.description
                            self.showWebView = true
                        }
                    }
                } else if let error = error {
                    print("Error searching for video: \(error)")
                }
            }.resume()
        }
    }
// AccordionView definition
struct AccordionView: View {
    let title: String
    let items: [String]
    @State private var isExpanded: Bool = false

    var body: some View {
        VStack {
            Button(action: {
                withAnimation {
                    self.isExpanded.toggle()
                }
            }) {
                Text(title)
                    .frame(width:380, height:60)
                    .font(.custom("AbhayaLibre-SemiBold", size: 28))
                    .overlay(
                    RoundedRectangle(cornerRadius: 0).stroke(Color("TextColor"), lineWidth:3))
            }
            if isExpanded {
                ForEach(items, id: \.self) { item in
                    Text(item)
                        .foregroundColor(Color("TextColor"))
                        .font(.custom("AbhayaLibre-SemiBold", size: 22))
                        .padding()
                }
            }
        }
        .padding()
        .foregroundColor(Color("TextColor"))
        .background(Color.color)
        .cornerRadius(10)
        .shadow(radius: 5)
    }
}
struct NotificationView_Previews: PreviewProvider {
    static var previews: some View {
        NotificationView()
    }
}
