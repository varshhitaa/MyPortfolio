//
//  Deals.swift
//  FuelEase
//
//  Created by Hannah Roop on 12/6/23.
//

import SwiftUI

struct DealsView: View {
    // Array of strings for each box
    let boxTitles = ["Get points back every time you use Fuel Ease!", "4% FuelBack at Shell", "3% FuelBack at Sam's Club", "4% FuelBack at BP", "2% FuelBack at Mobil"]
    let boxImages = ["", "Shell", "Sams", "BP", "Mobil"]

    var body: some View {
        ZStack {
            Color("BackgroundColor")
                .edgesIgnoringSafeArea(.all)
            
            
            
            VStack {
                
                Rectangle()
                    .frame(width: 380, height: 690)
                    .foregroundColor(Color(red: 0.98, green: 0.953, blue: 0.941))
                    .cornerRadius(63)
                    .overlay(
                        RoundedRectangle(cornerRadius: 64)
                            .stroke(Color(red: 0.451, green: 0.235, blue: 0.149), lineWidth: 4)
                    )
                    .overlay(
                        VStack(spacing: 20) {
                            ForEach(0..<boxTitles.count, id: \.self) { index in
                                RoundedRectangle(cornerRadius: 30)
                                    .frame(width: 340, height: 100)
                                    .foregroundColor(.white)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 30)
                                            .stroke(Color(red: 0.451, green: 0.235, blue: 0.149), lineWidth: 2)
                                    )
                                 
                                
                                    .overlay(
                                        HStack {
                                            Text(boxTitles[index])
                                                .font(.custom("AbhayaLibre-ExtraBold", size: 20))
                                                .foregroundColor(Color("TextColor"))
                                            
                                            Spacer()
                                            
                                            Image(boxImages[index]) // Use the corresponding image
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 50, height: 50)
                                                .foregroundColor(.gray)
                                                .padding(.trailing, 10)
                                            
                                        }
                                            .padding(.leading,40)
                                    )
                            }
                            
                            
                                    
                        }
                        .padding(.top, 50)
                    )
                
                    .overlay(
                        NavigationLink(destination: AccountView()) {
                            Image(systemName: "person.circle")
                                .font(.largeTitle)
                                .padding()
                                .foregroundColor(.text)
                        }
                        .offset(x: 160, y: -380)
                    )
                
                    .overlay(
                        Text("Deals")
                            .font(.custom("AbhayaLibre-ExtraBold", size: 60)) // Using the custom font
                            .padding(.top, -410) // Adjust padding to move the title down
                            .padding(.bottom, 10)
                            .foregroundColor(Color("TextColor"))
                    )
                    
                    .overlay(
                        NavigationLink(
                            destination: Settings(),
                            label: {
                                Image(systemName: "gear")
                                    .font(.largeTitle)
                                    .padding()
                                    .foregroundColor(.text)
                            }
                        )
                        .offset(x: -160, y:-380 )
                    )
                    
                
                
                     
                    .padding(.top, 85)

                // NavigationLink or other components can go here
            }
        }
    }
}

struct DealsView_Previews: PreviewProvider {
    static var previews: some View {
        DealsView()
    }
}

#Preview {
    DealsView()
}
