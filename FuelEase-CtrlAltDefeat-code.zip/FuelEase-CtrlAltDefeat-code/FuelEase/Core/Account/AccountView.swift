import SwiftUI

struct AccountView: View {
    
    @ObservedObject private var userManager = UserManager.shared
    @State private var isEditProfileActive = false
    @State private var isviewdeals = false
    
    @Environment(\.presentationMode) private var presentationMode: Binding<PresentationMode>
    @State private var isLoggedOut: Bool = false
    @State private var logoutError: Bool = false
    
    let backgroundColor = Color("BackgroundColor")
    let textColor = Color("TextColor")
    let buttonColor = Color("ButtonColor")
    let borderColor = Color("BorderColor")
    
    var body: some View {
        NavigationView {
            
            // Account Tab Content
            ZStack {
                backgroundColor.edgesIgnoringSafeArea(.all)
                VStack(spacing: -75) {
                    HStack {
                        Spacer()
                            .navigationBarBackButtonHidden(true)
                            .toolbar(content: {
                                ToolbarItem (placement: .navigationBarLeading)  {
                                    
                                    Button(action: {
                                        presentationMode.wrappedValue.dismiss()
                                    }, label: {
                                        Image(systemName: "arrow.left")
                                        //Image(systemName: "house.fill")
                                            .foregroundColor(Color("TextColor"))
                                        Text("Back")
                                            .foregroundColor(Color("TextColor"))
                                            .font(.custom("AbhayaLibre-ExtraBold", size: 22))
                                        
                                    })
                                    
                                }
                            })
                    }
                    .padding(.horizontal, 16)
                    
                    VStack(spacing: 45) {
                        RoundedRectangle(cornerRadius: 27)
                            .foregroundColor(Color(red: 0.98, green: 0.953, blue: 0.941))
                            .overlay(
                                VStack {
                                    Image(systemName: "person.crop.circle.fill")
                                        .resizable()
                                        .frame(width: 80, height: 80)
                                        .padding(.top, 40)
                                    
                                    // made change
                                HStack {
                                    Text(userManager.currentUser?.firstName ?? "")
                                      .font(.custom("AbhayaLibre-SemiBold", size: 22))
                                      .padding(.top, 10)
                                                            
                                    Text(userManager.currentUser?.lastName ?? "")
                                       .font(.custom("AbhayaLibre-SemiBold", size: 22))
                                       .padding(.top, 10)
                                }
                                                        
                                        // made change
                                    Text(userManager.currentUser?.email ?? "")
                                        .font(.custom("AbhayaLibre-SemiBold", size: 16 ))
                                        .foregroundColor(.black)
                                        .padding(.top, 5)
                                                        
                                
                        NavigationLink(destination: EditProfile(), isActive: $isEditProfileActive) {
                                EmptyView()
                                    }
                                    
                        NavigationLink(destination: DealsView(), isActive: $isviewdeals) {
                                            EmptyView()
                                                }
                                                        
                        Button(action: {isEditProfileActive = true}) {
                            HStack {
                            Image(systemName: "pencil")
                            Text("Edit Profile")
                                .font(.custom("AbhayaLibre-SemiBold", size: 20))}
                                .padding(.vertical, 12)
                                .padding(.horizontal, 40)
                                .background(buttonColor)
                                .foregroundColor(textColor)
                                .cornerRadius(25)
                                .shadow(color: Color.black.opacity(0.1), radius: 2, x: 0, y: 2)
                                .padding(.top, 70)}
                                    
                                    Button(action: {isviewdeals = true}) {
                                        HStack {
                                            Image(systemName: "tag")
                                            Text("View Deals")
                                                .font(.custom("AbhayaLibre-SemiBold", size: 20)) // Use the custom font
                                        }
                                        .padding(.vertical, 12)
                                        .padding(.horizontal, 40)
                                        .background(buttonColor)
                                        .foregroundColor(textColor)
                                        .cornerRadius(25)
                                        .shadow(color: Color.black.opacity(0.1), radius: 2, x: 0, y: 2)
                                        .padding(.top, 10)
                                    }
                                    Spacer()
                                    
                                    NavigationLink(destination:LogoutView()) {
                                        Text("Log Out")
                                            .font(.custom("AbhayaLibre-SemiBold", size: 22))
                                            .padding(.vertical, 12)
                                            .padding(.horizontal, 40)
                                            .cornerRadius(25)
                                            .background(Color("TextColor"))
                                            .foregroundColor(Color("Color"))
                                    }
                                    .cornerRadius(25)
                                    .padding(.bottom, 55)
                                    .alert(isPresented: $logoutError) {
                                        Alert(
                                            title: Text("Logout Failed"),
                                            message: Text("Logout failed, please try again."),
                                            dismissButton: .default(Text("OK"))
                                        )
                                    }
                                    
                                }
                            )
                            .overlay(RoundedRectangle(cornerRadius: 25)
                                .stroke(Color("TextColor"), lineWidth: 3))
                            .frame(width: 362, height: 633)
                            .shadow(color: Color.black.opacity(0.25), radius: 4, x: 0, y: 4)
                            .padding(.top, 100)
                        Spacer()
                    }
                }
            }
            
        }
        
        .navigationBarBackButtonHidden(true)
    }
}

struct AccountView_Previews: PreviewProvider {
    static var previews: some View {
        AccountView()
    }
}


