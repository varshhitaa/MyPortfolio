////
////  BackButtonView.swift
////  FuelEase
////
////  Created by temp on 11/16/23.
////
//
//import Foundation
//import SwiftUI
//
//struct BackButtonView: View {
//    var body: some View{
//        NavigationLink(destination: HomeView()) {
//                Button(action:{},
//                       label:{
//                    
//                    VStack (){
//                        Image(systemName: "house")
//                            .frame(width: 32.0, height: 32.0)
//                        
//                    }
//
//                })
//
//            
//        }
//    }
//}
//
//#Preview {
//    BackButtonView()
//}
