import SwiftUI
import FirebaseFirestore


struct GasStation: Identifiable {
    var id: String
    var name: String
    var address: String
    var price: Double
       init(id: String = UUID().uuidString, name: String, address: String, price: Double) {
           self.id = id
           self.name = name
           self.address = address
           self.price = price
       }
   }




struct GasFinderView: View {
    @State private var gasStations: [GasStation] = []
    @State private var favorites: [GasStation] = []
    @State private var selectedStation: GasStation?
    @State private var isRateStationActive: Bool = false
    @Environment(\.presentationMode) private var presentationMode: Binding<PresentationMode>

    
    var body: some View {
        NavigationView {
            ZStack {
                Color("BackgroundColor")
                    .ignoresSafeArea()
                
                VStack {
                    HStack {
                        NavigationLink(
                            destination: Settings(),
                            label: {
                                Image(systemName: "gear")
                                    .font(.largeTitle)
                                    .padding()
                                    .padding(.bottom, 20)
                                    .foregroundColor(Color("TextColor"))
                            }
                        )
                        Spacer()
                        NavigationLink(
                            destination: AccountView(),
                            label: {
                                Image(systemName: "person.circle")
                                    .font(.largeTitle)
                                    .padding()
                                    .padding(.bottom,20)
                                    .foregroundColor(.text)
                            }
                        )

                    }.padding(.top, 200)
                    
                    VStack {
                        ZStack {
                            Text("Gas Finder")
                                .font(.custom("AbhayaLibre-ExtraBold", size: 68))
                                .fontWeight(.bold)
                                .foregroundColor(Color("TextColor"))
                                .multilineTextAlignment(.center)
                                .padding(.top, -8)
                        }.background(RoundedRectangle(cornerRadius: 500)
                            .fill(Color.white)
                            .frame(width: 410, height: 150)
                            .overlay(RoundedRectangle(cornerRadius: 500)
                                .stroke(Color("TextColor"), lineWidth: 2)))
                        
                      
    .navigationBarBackButtonHidden(true)
                    .toolbar(content: {
                        ToolbarItem (placement: .navigationBarLeading)  {
                            
                            Button(action: {
                                presentationMode.wrappedValue.dismiss()
                            }, label: {
                                Image(systemName: "arrow.left")
                                //Image(systemName: "house.fill")
                                    .foregroundColor(Color("TextColor"))
                                Text("back")
                                    .foregroundColor(Color("TextColor"))
                                    .font(.custom("AbhayaLibre-ExtraBold", size: 22))
                                
                            })
                            
                        }
                    })

                        
                        VStack {
                            List(gasStations, id: \.name) { station in
                                HStack {
                                    VStack(alignment: .leading) {
                                        HStack {
                                            Text(station.name)
                                                .font(.custom("AbhayaLibre-ExtraBold", size: 28))
                                                .foregroundColor(Color("TextColor"))
                                            
                                            Spacer()
                                            
                                            Image(systemName: favorites.contains(where: { $0.id == station.id }) ? "heart.fill" : "heart")
                                                .font(.system(size: 22))
                                                .foregroundColor(.red)
                                                .onTapGesture {
                                                    toggleFavorite(station)
                                                }
                                                .padding(.trailing, -300000)
                                        }
                                        Text(station.address)
                                            .font(.custom("AbhayaLibre-SemiBold", size: 22))
                                            .foregroundColor(Color("TextColor"))
                                        
                                        Text("Rate this gas station")
                                            .font(.custom("AbhayaLibre-SemiBold", size: 18))
                                            .foregroundColor(Color.blue)
                                            .onTapGesture {
                                                navigateToRateGasStation(station)
                                            }
                                    }
                                    .padding(10)
                                    
                                    Spacer()
                                    
                                    Text(String(format: "$%.2f", station.price))
                                        .font(.custom("AbhayaLibre-SemiBold", size: 22))
                                        .foregroundColor(Color("TextColor"))
                                        .padding(10)
                                }
                                .background(RoundedRectangle(cornerRadius: 20)
                                    .fill(Color("Color"))
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 20)
                                            .stroke(Color("TextColor"), lineWidth: 2)
                                    )
                                )
                                .padding(.vertical, 5)
                            }
                            .onAppear {
                                fetchGasStations()
                            }
                            .listStyle(PlainListStyle())
                        }
                        .padding(.top, -50)
                        .frame(height: 750)
                        .background(Color.white)
                    }
                }
                
                NavigationLink(
                    destination: RateGasStationView(gasStation: selectedStation ?? GasStation(name: "", address: "", price: 0)),
                    isActive: $isRateStationActive,
                    label: { EmptyView() }
                )
                .hidden()
            }
        }
        .navigationBarBackButtonHidden(true)
    }
    
    private func saveFavoritesToFirestore() {
        let db = Firestore.firestore()
        let favoritesCollection = db.collection("favorites")

        for favorite in favorites {
            let data: [String: Any] = [
                "name": favorite.name,
                "address": favorite.address,
                "price": favorite.price
            ]

            favoritesCollection.document(favorite.id).setData(data) { error in
                if let error = error {
                    print("Error saving favorite to Firestore: \(error)")
                } else {
                    print("Successfully saved favorite: \(favorite.name)")
                }
            }
        }
    }


    private func fetchGasStations() {
        let db = Firestore.firestore()
        db.collection("reports").getDocuments { (snapshot, error) in
            guard let documents = snapshot?.documents else {
                print("Error fetching documents: \(error ?? NSError())")
                return
            }
            
            var fetchedGasStations: [GasStation] = []
            
            for document in documents {
                if let storeName = document["storeName"] as? String,
                   let location = document["location"] as? String,
                   let price = document["gasPrice"] as? Double {
                    let gasStation = GasStation(id: document.documentID, name: storeName, address: location, price: price)
                                fetchedGasStations.append(gasStation)
                }
            }
            
            self.gasStations = fetchedGasStations
        }
    }
    
    private func toggleFavorite(_ station: GasStation) {
        if let index = favorites.firstIndex(where: { $0.id == station.id }) {
            favorites.remove(at: index)
        } else {
            favorites.append(station)
        }

        // Print the current list of favorites
        print("Current Favorites: \(favorites.map { $0.name })")
        
        saveFavoritesToFirestore()
    }

    
   
    
    
        
        private func navigateToRateGasStation(_ station: GasStation) {
            selectedStation = station
            isRateStationActive = true
        }
    
    
    }




struct GasFinderView_Previews: PreviewProvider {
    static var previews: some View {
        GasFinderView()
          
    }
}
