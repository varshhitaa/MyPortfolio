//
//  RateGasStationView.swift
//  FuelEase
//
//  Created by Daria Rizvanova on 12/6/23.
//
import SwiftUI
import FirebaseFirestore

struct RateGasStationView: View {
    var gasStation: GasStation
    @State private var cleanliness: Int = 0
    @State private var fuelPricing: Int = 0
    @State private var safetySecurity: Int = 0
    @State private var overallExperience: Int = 0
    @State private var submitSuccess = false
    @Environment(\.presentationMode) private var presentationMode: Binding<PresentationMode>
    
    private func submitRating() {
        let db = Firestore.firestore()
        
        let data: [String: Any] = [
            "gasStationName": gasStation.name, // Include gas station name in the data
            "cleanliness": cleanliness,
            "fuelPricing": fuelPricing,
            "safetySecurity": safetySecurity,
            "overallExperience": overallExperience
        ]
        
        db.collection("gasStationrate").addDocument(data: data) { error in
            if let error = error {
                print("Error adding report: \(error.localizedDescription)")
            } else {
                submitSuccess = true
                cleanliness = 0
                fuelPricing = 0
                safetySecurity = 0
                overallExperience = 0
            }
            
        }
        
    }
      
    
    var body: some View {
        ZStack {
            Color("BackgroundColor")
                .ignoresSafeArea()
            
            VStack(spacing: 20) {
                HStack {
                    NavigationLink(
                        destination: Settings(),
                        label: {
                            Image(systemName: "gear")
                                .font(.largeTitle)
                                .padding()
                                .padding(.top,25)
                                .foregroundColor(.text)
                        }
                    )
                    Spacer()
                    NavigationLink(
                        destination: AccountView(),
                        label: {
                            Image(systemName: "person.circle")
                                .font(.largeTitle)
                                .padding()
                                .padding(.top,25)
                                .foregroundColor(.text)
                        }
                    )
                    
                }
                Spacer()
                    .navigationBarBackButtonHidden(true)
                    .toolbar(content: {
                        ToolbarItem (placement: .navigationBarLeading)  {
                            
                            Button(action: {
                                presentationMode.wrappedValue.dismiss()
                            }, label: {
                                Image(systemName: "arrow.left")
                                //Image(systemName: "house.fill")
                                    .foregroundColor(Color("TextColor"))
                                Text("back")
                                    .foregroundColor(Color("TextColor"))
                                    .font(.custom("AbhayaLibre-ExtraBold", size: 22))
                                
                            })
                            
                        }
                    })
                Text("Rate \(gasStation.name)")
                    .font(.custom("AbhayaLibre-ExtraBold", size: 50))
                    .padding()
                    .foregroundColor(Color("TextColor"))
                
                
                RatingSection(title: "Cleanliness", rating: $cleanliness)
                RatingSection(title: "Fuel Pricing", rating: $fuelPricing)
                RatingSection(title: "Safety and Security", rating: $safetySecurity)
                RatingSection(title: "Overall Experience", rating: $overallExperience)
                
                Button("Submit".uppercased()) {
                    submitRating()
                }
                .foregroundColor(Color("TextColor"))
                .font(.custom("AbhayaLibre-Bold", size: 24))
                .padding()
                .padding(.horizontal, 40)
                .foregroundColor(Color.text)
                .shadow(radius: 5)
                .background(
                    Capsule()
                        .stroke(Color.text, lineWidth: 6.0)
                        .fill(Color.button)
                        .shadow(radius: 5)
                )
            }
            .padding(.bottom,40)
            .navigationBarBackButtonHidden(true)
            
        }
        .alert("Thank you for your rating!", isPresented: $submitSuccess) {
            Button("OK", role: .cancel) { }
        }
        
    }
       
}
  

struct RatingSection: View {
    var title: String
    @Binding var rating: Int
    
    var body: some View {
        RoundedRectangle(cornerRadius: 40)
            .fill(Color("Color"))
            .frame(width: 370, height: 100)
            .overlay(
                RoundedRectangle(cornerRadius: 40)
                    .stroke(Color("TextColor"), lineWidth: 2)
            )
            .overlay(
                VStack {
                    Text(title)
                        .font(.custom("AbhayaLibre-Bold", size: 20))
                    
                    HStack {
                        ForEach(1 ..< 6) { index in
                            Button(action: {
                                rating = index
                            }) {
                                Image(systemName: index <= rating ? "star.fill" : "star")
                                    .resizable()
                                    .frame(width: 30, height: 30)
                                    .foregroundColor(.yellow)
                            }
                        }
                    }
                    
                    Text("Your Rating: \(rating) stars").font(.custom("AbhayaLibre-Bold", size: 16))
                }
            )
    }
}

struct RateGasStationView_Previews: PreviewProvider {
    static var previews: some View {
        let sampleGasStation = GasStation(name: "Sample Gas Station", address: "123 Main St", price: 2.99)
        return RateGasStationView(gasStation: sampleGasStation)
    }
}
