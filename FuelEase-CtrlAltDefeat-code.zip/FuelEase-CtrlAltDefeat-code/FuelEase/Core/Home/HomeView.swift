import SwiftUI

struct HomeView: View {
    init() {
        let tabBarAppearance = UITabBarAppearance()
        tabBarAppearance.configureWithOpaqueBackground()
        
        
        tabBarAppearance.backgroundColor = UIColor(named: "ButtonColor")
        
        tabBarAppearance.stackedLayoutAppearance.normal.iconColor = UIColor(named:"TextColor")
        tabBarAppearance.stackedLayoutAppearance.normal.titleTextAttributes = [.foregroundColor: UIColor(named: "TextColor")]
        
        tabBarAppearance.stackedLayoutAppearance.selected.iconColor = UIColor(named:"Color")
        tabBarAppearance.stackedLayoutAppearance.selected.titleTextAttributes = [.foregroundColor: UIColor(named:"Color")]
        
        
        UITabBar.appearance().standardAppearance = tabBarAppearance
        if #available(iOS 15.0, *) {
            UITabBar.appearance().scrollEdgeAppearance = tabBarAppearance
        }
    }
    var body: some View {
        NavigationView {
            // Home Tab
            TabView {
                ZStack {
                    Color("BackgroundColor")
                        .ignoresSafeArea()
                    
                    VStack {
                        HStack {
                            NavigationLink(
                                destination: Settings(),
                                label: {
                                    Image(systemName: "gear")
                                        .font(.largeTitle)
                                        .padding()
                                        .foregroundColor(.text)
                                }
                            )
                            Spacer()
                            NavigationLink(
                                destination: AccountView(),
                                label: {
                                    Image(systemName: "person.circle")
                                        .font(.largeTitle)
                                        .padding()
                                        .foregroundColor(.text)
                                }
                            )
                        }
                        Spacer()
                        Text("My Home")
                            .font(.custom("AbhayaLibre-ExtraBold", size: 55))
                            .foregroundColor(Color("TextColor"))
                            .padding(.bottom, 20)
                        Spacer()
                        
                        NavigationLink(destination: SearchView()) {
                            Text("Find cheap gas now")
                                .font(.custom("AbhayaLibre-ExtraBold", size: 32))
                                .padding()
                                .padding(.horizontal, 10)
                                .foregroundColor(Color.text)
                                .shadow(radius: 5)
                                .background(
                                    Capsule()
                                        .stroke(Color.text, lineWidth: 6.0)
                                        .fill(Color.button)
                                        .shadow(radius: 5)
                                )
                        }
                        .padding(.bottom, 20)
                        
                        NavigationLink(destination: PriceReportView()) {
                            Text("Report gas price")
                                .font(.custom("AbhayaLibre-ExtraBold", size: 32))
                                .padding()
                                .padding(.horizontal, 30)
                                .foregroundColor(Color.text)
                                .background(
                                    Capsule()
                                        .stroke(Color.text, lineWidth: 6.0)
                                        .fill(Color.button)
                                )
                                .shadow(radius: 5)
                        }
                        .padding(.bottom, 300)
                    }
                }
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
                .tag(1)
               
          
                MapView()
                    .tabItem {
                        Image(systemName: "map.fill")
                        Text("Map")
                    }
                    .tag(2)
                PriceReportView()
                    .tabItem {
                    Image(systemName: "doc.fill")
                    Text("Price Log")
                    }
                    .tag(3)
                
                NotificationView()
                    .tabItem {
                      Image(systemName: "bell.fill")
                      Text("Notifications")
                    }
                    .tag(4)
                
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}


