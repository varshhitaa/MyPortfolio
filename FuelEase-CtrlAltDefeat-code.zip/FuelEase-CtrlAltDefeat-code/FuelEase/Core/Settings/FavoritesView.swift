import SwiftUI
import FirebaseFirestore

struct FavoritesView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @State private var favoriteStations: [GasStation] = []

    var body: some View {
        ZStack {
            Color("BackgroundColor").ignoresSafeArea()
            
            VStack {
                HStack {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }, label: {
                        
                        
                    })
                    Spacer()
                }
                .padding()
                
                Text("My Favorites")
                    .font(.custom("AbhayaLibre-ExtraBold", size: 55))
                    .foregroundColor(Color("TextColor"))
                    .padding(.top, 50)
                
                // Your List starts here
                List(favoriteStations, id: \.id) { station in
                    favoriteStationRow(for: station)
                        .listRowBackground(Color.clear)
                        // This makes the List's row background transparent
                }
                .listStyle(PlainListStyle())
                .background(RoundedRectangle(cornerRadius: 20) // This is your rounded background
                    .fill(Color("Color"))
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color("TextColor"), lineWidth: 2)
                    )
                )
                .frame(width: 380, height: 500)
                .padding(.bottom, 50)

                Spacer()
            }
        }
        .onAppear {
            fetchFavorites()
        }
    }
    
    private func favoriteStationRow(for station: GasStation) -> some View {
        VStack(alignment: .leading) {
         
                Text(station.name)
                    .font(.custom("AbhayaLibre-ExtraBold", size: 28))
                    .foregroundColor(Color("TextColor"))
                Text(station.address)
                    .font(.custom("AbhayaLibre-SemiBold", size: 22))
                    .foregroundColor(Color("TextColor"))
                Text(String(format: "$%.2f", station.price))
                    .font(.custom("AbhayaLibre-SemiBold", size: 22))
                    .foregroundColor(Color("TextColor"))
            
        }
        
        .padding(10)
        .frame(width: 350)
        .background(RoundedRectangle(cornerRadius: 20)
            .fill(Color("BackgroundColor"))
            .stroke(Color("TextColor"), lineWidth: 2)
            .shadow(radius: 2))
    }

    private var favoritesList: some View {
            ScrollView {
                LazyVStack {
                    ForEach(favoriteStations, id: \.id) { station in
                        favoriteStationRow(for: station)
                    }
                }
            }
            .background(RoundedRectangle(cornerRadius: 20) // This is your rounded background
                .fill(Color("BackgroundColor"))
                .frame(maxWidth: .infinity, maxHeight: .infinity) // Adjusts the background to fill the available space
                .edgesIgnoringSafeArea(.all) // Extends the background to the edges of the screen
            )
        }
    private func fetchFavorites() {
        let db = Firestore.firestore()
        db.collection("favorites").getDocuments { (snapshot, error) in
            guard let documents = snapshot?.documents else {
                print("Error fetching documents: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            var fetchedFavorites: [GasStation] = []
            for document in documents {
                if let name = document["name"] as? String,
                   let address = document["address"] as? String,
                   let price = document["price"] as? Double {
                    let station = GasStation(id: document.documentID, name: name, address: address, price: price)
                    fetchedFavorites.append(station)
                }
            }
            self.favoriteStations = fetchedFavorites
        }
    }
}

struct FavoritesView_Previews: PreviewProvider {
    static var previews: some View {
        FavoritesView()
    }
}
