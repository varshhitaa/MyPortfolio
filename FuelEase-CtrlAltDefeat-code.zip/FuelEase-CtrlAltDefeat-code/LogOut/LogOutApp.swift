//
//  LogOutApp.swift
//  LogOut
//
//  Created by Diya Patel on 10/26/23.
//

import SwiftUI

@main
struct LogOutApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
