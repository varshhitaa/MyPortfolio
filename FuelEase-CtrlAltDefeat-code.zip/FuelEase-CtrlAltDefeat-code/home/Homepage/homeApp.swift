//
//  homeApp.swift
//  home
//
//  Created by Daria Rizvanova on 10/24/23.
//

import SwiftUI

@main
struct homeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
