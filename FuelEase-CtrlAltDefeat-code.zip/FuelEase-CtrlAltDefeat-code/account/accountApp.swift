//
//  accountApp.swift
//  account
//
//  Created by Varshita Yarabadi on 10/26/23.
//

import SwiftUI

@main
struct accountApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
