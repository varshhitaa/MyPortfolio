

// Function to validate the form inputs
function validateForm() {
  var name = document.getElementById("name").value;
  var email = document.getElementById("email").value;
  var date = document.getElementById("date").value;
  var time = document.getElementById("time").value;
  var guests = document.getElementById("guests").value;

  // Perform validation on each input
  if (name === "") {
    alert("Please enter your name.");
    return false;
  }
  if (email === "") {
    alert("Please enter your email.");
    return false;
  }
  

  if (time === "") {
    alert("Please select a time.");
    return false;
  }
  if (guests === "" || guests < 1) {
    alert("Please enter a valid number of guests.");
    return false;
  }

  // If all inputs are valid, return true to submit the form
  return true;
}



$(document).ready(function () {
  $("form").submit(function (event) {
    var formData = {
      name: $("#name").val(),
      email: $("#email").val(),
    };

    $.ajax({
      type: "POST",
      url: "reservation.html",
      data: formData,
      
      encode: true,
    }).done(function (data) {
      console.log(data);
   

    if (!data.success) {
      if (data.errors.name) {
        $("#name").addClass("has-error");
        $("#name").append(
          '<div class="help-block">' + data.errors.name + "</div>"
        );
      }

      if (data.errors.email) {
        $("#email").addClass("has-error");
        $("#email").append(
          '<div class="help-block">' + data.errors.email + "</div>"
        );
      }

       } else {
       $("form").html(
        '<div class="alert alert-success">' + data.message + "</div>"
      );
    }

  });

    event.preventDefault();
  });
});
