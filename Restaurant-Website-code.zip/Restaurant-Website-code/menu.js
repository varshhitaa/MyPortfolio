//accordin JQuery plugin
window.addEventListener("load", function() {
    // get all accordion titles
    const accordionTitles = document.querySelectorAll(".accordion-title");
  
    // loop through each accordion title
    accordionTitles.forEach(function(title) {
      // add click event listener to title
      title.addEventListener("click", function() {
        // get parent accordion item
        const parent = this.parentNode;
  
        // check if clicked item is already active
        if (parent.classList.contains("active")) {
          // if clicked item is already active, deactivate it
          parent.classList.remove("active");
        } else {
          // if clicked item is not active, activate it and deactivate any other active items
          const activeItems = document.querySelectorAll(".accordion-item.active");
          activeItems.forEach(function(item) {
            item.classList.remove("active");
          });
          parent.classList.add("active");
        }
      });
    });
  });
  

  