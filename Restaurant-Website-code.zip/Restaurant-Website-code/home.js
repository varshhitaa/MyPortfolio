document.addEventListener('DOMContentLoaded', () => {
    const slides = document.querySelector(".slides");
    const slideWidth = slides.clientWidth / 3;
    let currentPosition = 0;
  
    function slideTo(position) {
      slides.style.transform = `translateX(-${position * slideWidth}px)`;
      currentPosition = position;
    }
  
    document.querySelector(".arrow-left").addEventListener("click", () => {
      if (currentPosition > 0) {
        slideTo(currentPosition - 1);
      }
    });
  
    document.querySelector(".arrow-right").addEventListener("click", () => {
      if (currentPosition < 2) {
        slideTo(currentPosition + 1);
      }
    });
  });

  $(function () {
    $('.btnClass').click(function (event) {
        event.preventDefault();
        $(this).button();
    });
});




// jQuery code
$(document).ready(function() {
  // Show/hide menu
  $('.menu-toggle').click(function() {
    $('.menu').slideToggle();
  });
});
  


  

  

  
   

