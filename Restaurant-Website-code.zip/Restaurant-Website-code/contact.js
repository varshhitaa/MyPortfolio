// Get the form element
const contactForm = document.querySelector('.contact-form');

// Add submit event listener to the form
contactForm.addEventListener('submit', (e) => {
    e.preventDefault(); // Prevent form submission
    // Get form input values
    const name = contactForm.querySelector('#name').value;
    const email = contactForm.querySelector('#email').value;
    const phoneNumber = contactForm.querySelector('#number').value;
    const message = contactForm.querySelector('#message').value;
    // Perform form validation
    if (name === '' || email === '' || phoneNumber === '' || message === '') {
        alert('Please fill in all the fields.');
    } else {
        // Validate phone number format
        const phoneRegex = /^\d{3}-\d{3}-\d{4}$/; // Example format: xxx-xxx-xxxx
        if (!phoneRegex.test(phoneNumber)) {
           alert('Please enter a valid phone number in the format: xxx-xxx-xxxx.');
        } else {
            // Form data is valid, perform form submission or other actions here
            alert('Form submitted successfully!');
            // Reset the form
            contactForm.reset();
        }
    }
});


