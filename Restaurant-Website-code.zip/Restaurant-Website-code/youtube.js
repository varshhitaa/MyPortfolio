//youtube
"use strict";

// Get the input from the text box
function get_video(){
  let text_value = $("#text_input").val();

/* The offcial doc for the youtube api
https://developers.google.com/youtube/v3/docs/search/list
*/

  $.ajax({
        type: 'GET',
        url: 'https://www.googleapis.com/youtube/v3/search',
        data: {
            key: 'AIzaSyBtDLwKoVF_qln1aikD8Ec-s61zyngkuV4',
            q: text_value,
            part: 'snippet',
            maxResults: 1,
            type: 'video',
            videoEmbeddable: true,
        }
  }).done(function(data){
          $('iframe').attr('src', 'https://www.youtube.com/embed/' + data.items[0].id.videoId)
          $('h3').text(data.items[0].snippet.title)
          $('.description').text(data.items[0].snippet.description)
          $('#show_result').show()
          $('#input_value').hide()
  }).fail(function(response){
            console.log("Request Failed");
  });
};

$(document).ready(function() {
  $("#get_a_youtube_video").click(get_video);
});